#include "config.h"
#include "lcd.h"
//#include "I2C.h"
//#include"RTC.h"

void Init_LCD(void)
{
    /*  making Pins as output   */
    PORTCbits.RC7= 0;  //  Enable pin of LCD 
    PORTCbits.RC6= 0;  //  RS pin of LCD 
    PORTD   = 0;       //  DATA pin FOR LCD 8bits  port D as output   
    TRISD   = 0;         // Direction for Port D
    TRISCbits.TRISC7    = 0;//Direction for Port C bit 7 EN
    TRISCbits.TRISC6       = 0; // Direction for Port C 6 Rs Pin
   __delay_ms(10);          /*  10ms delay   */
   /*   writing commands for initialization of LCD  */
   Lcd_Cmd(0x38);  //  Functions Set as Given in Datasheet 
   Lcd_Cmd(0x0F);  //  Display ON; Cursor ON; Blink ON     
   Lcd_Cmd(0x06);  //  Display Shifting OFF                
   Lcd_Clear();   //  Clear Display                       
}   



void Lcd_Clear(void)
{
    Lcd_Cmd(0x01);         //  Clear Screen command    
    __delay_ms(3);                                           
}

void Lcd_Port(void)
{
  // toggling Enable PIN is must for data to be displayed on screen
    PORTCbits.RC7 = 1;
    __delay_us(200);
    PORTCbits.RC7 = 0;
    __delay_us(200);
}

/*^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^*/

void Lcd_Cmd(unsigned char Cmd)
{
    PORTCbits.RC6   = 0;        // For command RS must be low (0)     
    PORTD  = Cmd;      //  write Command to data pins of LCD    

    Lcd_Port();
}

/*^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^*/

void Lcd_Write_Char(unsigned char Data)
{
    PORTCbits.RC6  = 1;        //  For data RS must be high (1)    
    PORTD = Data;     //  write data to data bus of LCD   
    Lcd_Port();
}

void Lcd_Write_String(const char *String)
{
    while(*String)
    {
        Lcd_Write_Char(*String++);   // Display data until string ends 
    }
}

/*^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^*/

unsigned char Lcd_Set_Cursor(unsigned char Address)
{
    //  valid addresses are for line one 0x80 and line two are 0xC0   
    if ((Address >= 0x80 && Address <= 0xA8) || (Address >= 0xC0 && Address <= 0xE8))
    {
       Lcd_Cmd(Address);
        return 1;
    }
    else
        return 0;
}